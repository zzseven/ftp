#include <sys/types.h>
#include <sys/socket.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <string.h>
#include <sys/epoll.h>
#include <sys/time.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/stat.h>
#include <fcntl.h>

typedef struct tdata{
	int len;
	char buf[1000];
}data_t, *pdata_t;

int recv_file(int sfd);
int send_file(int sfd);
void send_n(int sfd, char* p, int len);
